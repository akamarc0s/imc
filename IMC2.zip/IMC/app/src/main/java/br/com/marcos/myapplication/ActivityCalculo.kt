package br.com.marcos.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calculo.*

class ActivityCalculo : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculo)

        // Set a SeekBar change listener
        sekAltura.setOnSeekBarChangeListener( object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(sekAltura: SeekBar, iAltura: Int, b: Boolean) {
                // Display the current progress of SeekBar
                txtAltura.text = "Altura : $iAltura m"
            }

            override fun onStartTrackingTouch(sekAltura: SeekBar) {
                // called when tracking the seekbar is started
            }

            override fun onStopTrackingTouch(sekAltura: SeekBar) {
                // called when tracking the seekbar is stopped
            }
        })

        sekPeso.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar, iPeso: Int, b: Boolean) {
                // Display the current progress of SeekBar
                txtPeso.text = "Peso : $iPeso kg"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Do something
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Do something
            }

        })

        btnCalculo.setOnClickListener {

            val minhaPreferencia = getSharedPreferences ("minha-preferencia", Context.MODE_PRIVATE)
            val meuEditor = minhaPreferencia.edit()
            val peso = txtAltura.text.toString().toInt()
            val altura = txtPeso.text.toString() .toInt()


            if((peso == null || altura == null)){
              Toast.makeText(this@ActivityCalculo, "Preencha Corretamente!", Toast.LENGTH_LONG).show()
          }
          else{
              meuEditor.putInt("altura", altura).apply()
              meuEditor.putInt("peso", peso).apply()
              startActivity(Intent(this@ActivityCalculo, ActivityResultado::class.java))
          }
      }

        btnTabela.setOnClickListener {
            startActivity(Intent(this@ActivityCalculo, ActivityTabela::class.java))
        }
    }

}
