package br.com.marcos.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class ActivitySplash : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Criando a intenção de ir para a tela de calculo do imc
        val intentTelaCalculo = Intent(this@ActivitySplash, ActivityCalculo::class.java)

        Handler().postDelayed({ // iniciando a transição para a tela de cálculo
            startActivity(intentTelaCalculo)
            // finalizando esta activity
            finish()
        },3000)

    }
}
