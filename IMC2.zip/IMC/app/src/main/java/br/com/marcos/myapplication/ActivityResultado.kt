package br.com.marcos.myapplication

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_resultado.*

class ActivityResultado : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val minhaPreferencia = getSharedPreferences("minha-preferencia", Context.MODE_PRIVATE)



        val altura = minhaPreferencia.getInt("altura", 0)
        val peso = minhaPreferencia.getInt("peso", 0)

        val imc = peso/((altura*altura)/100000)
        if (imc <19){
            txvGrau.text = "Você está abaixo do peso!"
        }
        else if(imc > 32)
            txvGrau.text = "Acima do peso!"
    }
        else{
         txvGrau.text = "Peso normal!"
        }

      txvImc.text = "Seu IMC É: $imc"

}

}
